//
//  StartViewController.swift
//  CordovaApp
//
//  Created by Swetha Sreekanth on 15/8/20.
//

import Foundation
import UIKit
class StartViewController: UIViewController {
    init() {
        super.init(nibName: "StartViewController", bundle: Bundle.main)
    }
    
    @IBAction func buttonClic(_ sender: Any) {
        let newVC = MainViewController()
        self.navigationController?.pushViewController(newVC, animated: false)
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad() {
      super.viewDidLoad()
     
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    func navigateToDashBoard() {
        
    }
}
